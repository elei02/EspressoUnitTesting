package com.example.emptyviewsactivityproject

import org.junit.runners.Suite
import org.junit.runner.RunWith

//This lets us run all the tests at once
@RunWith(Suite::class)
@Suite.SuiteClasses(MainActivityTest::class, CreateAccountActivityTest::class)
class AppTests