package com.example.emptyviewsactivityproject

import androidx.test.espresso.Espresso
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest{
    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)
    //Tests visibility of page and elements
    //Tests if users can click or put input as expected
    @Test
    fun checkLoginPageVisibile(){
        onView(withId(R.id.login_page)).check(matches(isDisplayed()))
    }

    @Test
    fun checkTitle(){
        onView(withId(R.id.textView)).check(matches(isDisplayed()))
        onView(withId(R.id.textView)).check(matches(withText(R.string.login_title)))
    }
    @Test
    fun checkUsernameField(){
        onView(withId(R.id.editTextText)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextText)).check(matches(withHint(R.string.username_hint)))
        onView(withId(R.id.editTextText)).check(matches(supportsInputMethods()))
    }
    @Test
    fun checkPasswordField(){
        onView(withId(R.id.editTextText2)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextText2)).check(matches(withHint(R.string.password_hint)))
        onView(withId(R.id.editTextText2)).check(matches(supportsInputMethods()))
    }
    @Test
    fun checkLoginButtonVisible(){
        onView(withId(R.id.button)).check(matches(isDisplayed()))
        onView(withId(R.id.button)).check(matches(isClickable()))
    }
    @Test
    fun checkCreateAccountButton(){
        onView(withId(R.id.textView3)).check(matches(isDisplayed()))
        onView(withId(R.id.textView3)).check(matches(isClickable()))
    }
    @Test
    fun checkHelpButton(){
        onView(withId(R.id.textView2)).check(matches(isDisplayed()))
        onView(withId(R.id.textView2)).check(matches(isClickable()))
    }
    //Tests Navigations
    @Test
    fun toRegistration(){
        onView(withId(R.id.textView3)).perform(click())
        onView(withId(R.id.RegistrationPage)).check(matches(isDisplayed()))
    }
    @Test
    fun backButton(){
        onView(withId(R.id.textView3)).perform(click())
        onView(withId(R.id.RegistrationPage)).check(matches(isDisplayed()))
        Espresso.pressBack()
        onView(withId(R.id.login_page)).check(matches(isDisplayed()))

    }
}