package com.example.emptyviewsactivityproject

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class CreateAccountActivityTest{
    @get:Rule
    val activityRule = ActivityScenarioRule(CreateAccountActivity::class.java)
    //Tests visibility of page and elements
    //Tests if users can click or put input as expected
    @Test
    fun checkPage(){
        onView(withId(R.id.RegistrationPage)).check(matches(isDisplayed()))
    }
    @Test
    fun checkBackButton(){
        onView(withId(R.id.floatingActionButton)).check(matches(isDisplayed()))
    }
    @Test
    fun checkTitle(){
        onView(withId(R.id.textView4)).check(matches(isDisplayed()))
        onView(withId(R.id.textView4)).check(matches(withText(R.string.registration_title)))
    }
    @Test
    fun checkEmailField(){
        onView(withId(R.id.editTextText3)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextText3)).check(matches(withHint(R.string.email_address)))
        onView(withId(R.id.editTextText3)).check(matches(supportsInputMethods()))
    }
    @Test
    fun checkUserField(){
        onView(withId(R.id.editTextText6)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextText6)).check(matches(withHint(R.string.username_hint)))
        onView(withId(R.id.editTextText6)).check(matches(supportsInputMethods()))
    }
    @Test
    fun checkPasswordField(){
        onView(withId(R.id.editTextText7)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextText7)).check(matches(withHint(R.string.password_hint)))
        onView(withId(R.id.editTextText7)).check(matches(supportsInputMethods()))
    }
    @Test
    fun checkConfirmationField(){
        onView(withId(R.id.editTextText8)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextText8)).check(matches(withHint(R.string.password_confirm)))
        onView(withId(R.id.editTextText8)).check(matches(supportsInputMethods()))
    }
    //Testing navigation to login page
    @Test
    fun toLogin(){
        onView(withId(R.id.floatingActionButton )).perform(ViewActions.click())
        onView(withId(R.id.login_page)).check(matches(isDisplayed()))
    }
}