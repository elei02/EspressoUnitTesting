package com.example.emptyviewsactivityproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.emptyviewsactivityproject.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.textView3.setOnClickListener{
            startActivity(Intent(this,CreateAccountActivity::class.java))
        }

        binding.floatingActionButton3.setOnClickListener{
            finishAndRemoveTask()
        }
    }
}