package com.example.emptyviewsactivityproject

import android.view.View
import android.R.*
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.emptyviewsactivityproject.databinding.ActivityCreateAccountBinding


class CreateAccountActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCreateAccountBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateAccountBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.floatingActionButton.setOnClickListener{
            //startActivity(Intent(this,MainActivity::class.java))
            onBackPressed()
        }
        binding.button2.setOnClickListener{
            val email = findViewById<EditText>(R.id.editTextText3).text.toString()
            val username = findViewById<EditText>(R.id.editTextText6).text.toString()
            val password = findViewById<EditText>(R.id.editTextText7).text.toString()
            val confirmPassword = findViewById<EditText>(R.id.editTextText8).text.toString()
            val errorMessage = findViewById<TextView>(R.id.textView6)
            if(email.isEmpty() || username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()){
                errorMessage.text = getString(R.string.errorEmptyFields)
                errorMessage.visibility = View.VISIBLE
            }
            else if(!(email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+".toRegex()))){
                errorMessage.visibility = View.VISIBLE
                errorMessage.text = getString(R.string.errorInvalidEmail)

            }
            else if(password != confirmPassword){
                errorMessage.visibility = View.VISIBLE
                errorMessage.text = getString(R.string.errorMismatchedPasswords)
            }
            else{
                errorMessage.visibility = View.INVISIBLE
            }

        }
    }
}