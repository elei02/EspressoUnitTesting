package com.example.emptyviewsactivityproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.example.emptyviewsactivityproject.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.textView3.setOnClickListener{
            startActivity(Intent(this,CreateAccountActivity::class.java))
        }

        binding.floatingActionButton3.setOnClickListener{
            finishAndRemoveTask()
        }
        binding.button.setOnClickListener{

            val email = findViewById<EditText>(R.id.editTextText).text.toString()
            val password = findViewById<EditText>(R.id.editTextTextPassword).text.toString()
            val errorMessage = findViewById<TextView>(R.id.textView5)
            if(email.isEmpty() && password.isEmpty()){
                errorMessage.text = getString(R.string.errorEmptyFields)
                errorMessage.visibility = View.VISIBLE
            }
            else if(email.isEmpty()) {
                errorMessage.visibility = View.VISIBLE
                errorMessage.text = getString(R.string.errorEmptyEmail)
            }
            else if(password.isEmpty()){
                errorMessage.text = getString(R.string.errorEmptyPassword)
                errorMessage.visibility = View.VISIBLE
            }
            else if(!(email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+".toRegex()))){
                errorMessage.visibility = View.VISIBLE
                errorMessage.text = getString(R.string.errorInvalidEmail)

            }
            else{
                errorMessage.visibility = View.INVISIBLE
                //Handle valid email and password
            }
        }
    }
}