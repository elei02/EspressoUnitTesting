package com.example.emptyviewsactivityproject

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.action.ViewActions.replaceText
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class CreateAccountActivityTest{
    @get:Rule
    val activityRule = ActivityScenarioRule(CreateAccountActivity::class.java)
    //Tests visibility of page and elements
    //Tests if users can click or put input as expected
    @Test
    fun checkPage(){
        onView(withId(R.id.RegistrationPage)).check(matches(isDisplayed()))
    }
    @Test
    fun checkBackButton(){
        onView(withId(R.id.floatingActionButton)).check(matches(isDisplayed()))
    }
    @Test
    fun checkTitle(){
        onView(withId(R.id.textView4)).check(matches(isDisplayed()))
        onView(withId(R.id.textView4)).check(matches(withText(R.string.registration_title)))
    }
    @Test
    fun checkEmailField(){
        onView(withId(R.id.editTextText3)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextText3)).check(matches(withHint(R.string.email_address)))
        onView(withId(R.id.editTextText3)).check(matches(supportsInputMethods()))
    }
    @Test
    fun checkUserField(){
        onView(withId(R.id.editTextText6)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextText6)).check(matches(withHint(R.string.username_hint)))
        onView(withId(R.id.editTextText6)).check(matches(supportsInputMethods()))
    }
    @Test
    fun checkPasswordField(){
        onView(withId(R.id.editTextText7)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextText7)).check(matches(withHint(R.string.password_hint)))
        onView(withId(R.id.editTextText7)).check(matches(supportsInputMethods()))
    }
    @Test
    fun checkConfirmationField(){
        onView(withId(R.id.editTextText8)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextText8)).check(matches(withHint(R.string.password_confirm)))
        onView(withId(R.id.editTextText8)).check(matches(supportsInputMethods()))
    }
    //Testing navigation to login page
    @Test
    fun toLogin(){
        onView(withId(R.id.floatingActionButton )).perform(ViewActions.click())
        onView(withId(R.id.login_page)).check(matches(isDisplayed()))
    }
    //Functional Tests
    @Test
    fun emptyFields(){
        //checks if fields are displayed and the error message is not showing
        onView(withId(R.id.editTextText3)).check(matches(isDisplayed()))//email field
        onView(withId(R.id.editTextText6)).check(matches(isDisplayed()))//user field
        onView(withId(R.id.editTextText7)).check(matches(isDisplayed()))//pw field
        onView(withId(R.id.editTextText8)).check(matches(isDisplayed()))//conf pw field
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
        //expect to see error message about empty fields appear
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorEmptyFields)))
        //populates fields with valid data
        onView(withId(R.id.editTextText3)).perform(replaceText("valid@email.com"))
        onView(withId(R.id.editTextText6)).perform(replaceText("validUsername"))
        onView(withId(R.id.editTextText7)).perform(replaceText("matchingPassword"))
        onView(withId(R.id.editTextText8)).perform(replaceText("matchingPassword"))
        //expect error message to become invisbile
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
    }
    @Test
    fun censoredPasswords(){
        //enters matching strings of length 16 into the password fields
        onView(withId(R.id.editTextText7)).check(matches(isDisplayed()))//pw field
        onView(withId(R.id.editTextText8)).check(matches(isDisplayed()))//conf pw field
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))//err msg
        onView(withId(R.id.editTextText7)).perform(replaceText("lengthOf16String"))
        onView(withId(R.id.editTextText8)).perform(replaceText("lengthOf16String"))
        val censoredPW = "•".repeat(16)
        //expect to see censored passwords stored
        onView(withId(R.id.editTextText7)).check(matches(withText(censoredPW)))
        onView(withId(R.id.editTextText8)).check(matches(withText(censoredPW)))
        //populates the rest of the fields with valid data
        onView(withId(R.id.editTextText3)).perform(replaceText("valid@email.com"))
        onView(withId(R.id.editTextText6)).perform(replaceText("validUsername"))
        //expect error message to become invisbile
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
    }
    @Test
    fun invalidEmail(){
        //checks if fields are there and all inputs are valid except for email
        onView(withId(R.id.editTextText3)).check(matches(isDisplayed()))//email field
        onView(withId(R.id.editTextText6)).check(matches(isDisplayed()))//user field
        onView(withId(R.id.editTextText7)).check(matches(isDisplayed()))//pw field
        onView(withId(R.id.editTextText8)).check(matches(isDisplayed()))//conf pw field
        onView(withId(R.id.editTextText3)).perform(replaceText("invalidEmail"))
        onView(withId(R.id.editTextText6)).perform(replaceText("validusername"))
        onView(withId(R.id.editTextText7)).perform(replaceText("lengthOf16String"))
        onView(withId(R.id.editTextText8)).perform(replaceText("lengthOf16String"))
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
        //expect error message about invalid email
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorInvalidEmail)))
        //enters a valid email
        onView(withId(R.id.editTextText3)).perform(replaceText("valid@email.com"))
        //expect error message to become invisbile
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
    }
    @Test
    fun mismatchedPasswords(){
        //checks for field elements and enters mismatched passwords with the other fields valid
        onView(withId(R.id.editTextText3)).check(matches(isDisplayed()))//email field
        onView(withId(R.id.editTextText6)).check(matches(isDisplayed()))//user field
        onView(withId(R.id.editTextText7)).check(matches(isDisplayed()))//pw field
        onView(withId(R.id.editTextText8)).check(matches(isDisplayed()))//conf pw field
        onView(withId(R.id.editTextText3)).perform(replaceText("valid@email.com"))
        onView(withId(R.id.editTextText6)).perform(replaceText("validPassword"))
        onView(withId(R.id.editTextText7)).perform(replaceText("matchingPassword"))
        onView(withId(R.id.editTextText8)).perform(replaceText("nonMatchingPassword"))
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))//err msg
        //expect error message about mismatched password
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorMismatchedPasswords)))
        //enters matching password and we expect error message to disappear
        onView(withId(R.id.editTextText8)).perform(replaceText("matchingPassword"))
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
    }
    @Test
    fun invalidEmailWithMismatchedPasswords(){
        onView(withId(R.id.editTextText3)).check(matches(isDisplayed()))//email field
        onView(withId(R.id.editTextText6)).check(matches(isDisplayed()))//user field
        onView(withId(R.id.editTextText7)).check(matches(isDisplayed()))//pw field
        onView(withId(R.id.editTextText8)).check(matches(isDisplayed()))//conf pw field

        onView(withId(R.id.editTextText3)).perform(replaceText("invalidEmail"))
        onView(withId(R.id.editTextText6)).perform(replaceText("exampleUser"))
        onView(withId(R.id.editTextText7)).perform(replaceText("password1"))
        onView(withId(R.id.editTextText8)).perform(replaceText("matchingPassword"))

        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))//err msg
        //expect error message about invalid email
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorInvalidEmail)))
        //inputs valid email
        onView(withId(R.id.editTextText3)).perform(replaceText("valid@email.com"))
        //expect error message about mismatched password
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorMismatchedPasswords)))
        //enters matching password
        onView(withId(R.id.editTextText7)).perform(replaceText("matchingPassword"))
        //expect no error message
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
    }
    @Test
    fun inputtingAndDeletingData(){
        onView(withId(R.id.editTextText3)).check(matches(isDisplayed()))//email field
        onView(withId(R.id.editTextText6)).check(matches(isDisplayed()))//user field
        onView(withId(R.id.editTextText7)).check(matches(isDisplayed()))//pw field
        onView(withId(R.id.editTextText8)).check(matches(isDisplayed()))//conf pw field
        //all fields currently empty
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
        onView(withId(R.id.button2)).perform(ViewActions.click())
        //expect error message about empty fields to appear
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorEmptyFields)))
        //Populate fields with mismatched passwords, valid email, and vail username
        onView(withId(R.id.editTextText3)).perform(replaceText("valid@email.com"))
        onView(withId(R.id.editTextText6)).perform(replaceText("exampleUser"))
        onView(withId(R.id.editTextText7)).perform(replaceText("password1"))
        onView(withId(R.id.editTextText8)).perform(replaceText("password2"))
        //expect error message about mismatched passwords
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorMismatchedPasswords)))
        //match passwords and enter an invalid email
        onView(withId(R.id.editTextText7)).perform(replaceText("matching"))
        onView(withId(R.id.editTextText8)).perform(replaceText("matching"))
        onView(withId(R.id.editTextText3)).perform(replaceText("invalid"))
        //expect message about invalid email
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorInvalidEmail)))
        //enter valid email and remove username field
        onView(withId(R.id.editTextText3)).perform(replaceText("valid@email.com"))
        onView(withId(R.id.editTextText6)).perform(replaceText(""))
        //expect message about empty fields
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorEmptyFields)))
        //enter a valid username
        onView(withId(R.id.editTextText6)).perform(replaceText("myUsername"))
        //expect error message to disappear
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
    }

}