package com.example.emptyviewsactivityproject

import androidx.test.espresso.Espresso
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.ViewAction
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.replaceText
import androidx.test.espresso.action.ViewActions.typeText
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest{
    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)
    //Tests visibility of page and elements
    //Tests if users can click or put input as expected
    @Test
    fun checkLoginPageVisibile(){
        onView(withId(R.id.login_page)).check(matches(isDisplayed()))
    }

    @Test
    fun checkTitle(){
        onView(withId(R.id.textView)).check(matches(isDisplayed()))
        onView(withId(R.id.textView)).check(matches(withText(R.string.login_title)))
    }
    @Test
    fun checkEmailField(){
        onView(withId(R.id.editTextText)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextText)).check(matches(withHint(R.string.email_address)))
        onView(withId(R.id.editTextText)).check(matches(supportsInputMethods()))
    }
    @Test
    fun checkPasswordField(){
        onView(withId(R.id.editTextTextPassword)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextTextPassword)).check(matches(withHint(R.string.password_hint)))
        onView(withId(R.id.editTextTextPassword)).check(matches(supportsInputMethods()))
    }
    @Test
    fun checkLoginButtonVisible(){
        onView(withId(R.id.button)).check(matches(isDisplayed()))
        onView(withId(R.id.button)).check(matches(isClickable()))
    }
    @Test
    fun checkCreateAccountButton(){
        onView(withId(R.id.textView3)).check(matches(isDisplayed()))
        onView(withId(R.id.textView3)).check(matches(isClickable()))
    }
    @Test
    fun checkHelpButton(){
        onView(withId(R.id.textView2)).check(matches(isDisplayed()))
        onView(withId(R.id.textView2)).check(matches(isClickable()))
    }
    //Tests Navigations
    @Test
    fun toRegistration(){
        onView(withId(R.id.textView3)).perform(click())
        onView(withId(R.id.RegistrationPage)).check(matches(isDisplayed()))
    }
    @Test
    fun backButton(){
        onView(withId(R.id.textView3)).perform(click())
        onView(withId(R.id.RegistrationPage)).check(matches(isDisplayed()))
        Espresso.pressBack()
        onView(withId(R.id.login_page)).check(matches(isDisplayed()))

    }
    //Functional Tests
    @Test
    fun passwordCensoring(){
        onView(withId(R.id.editTextTextPassword)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextTextPassword)).perform(replaceText("length14String"))
        var censoredPW = "•".repeat(14)
        onView(withId(R.id.editTextTextPassword)).check(matches(withText(censoredPW)))
        //enter a valid email
        onView(withId(R.id.editTextText)).perform(replaceText("valid@email.com"))
        //expect no error message
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
    }
    @Test
    fun emptyFields(){
        //checks if email and password fields are there then presses login
        onView(withId(R.id.editTextText)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextTextPassword)).check(matches(isDisplayed()))
        onView(withId(R.id.button)).check(matches(isDisplayed()))
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
        onView(withId(R.id.button)).perform(click())
        //expect an error message about empty fields
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView5)).check(matches(withText(R.string.errorEmptyFields)))
        //enter a valid email and password
        onView(withId(R.id.editTextText)).perform(replaceText("valid@email.com"))
        onView(withId(R.id.editTextTextPassword)).perform(replaceText("validPassword"))
        //expect no error message
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
    }
    @Test
    fun emptyEmail(){
        //check if fields are there and inputs a valid password
        onView(withId(R.id.editTextText)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextTextPassword)).check(matches(isDisplayed()))
        onView(withId(R.id.button)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextTextPassword)).perform(replaceText("testing"))
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
        //expect error message about empty email
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView5)).check(matches(withText(R.string.errorEmptyEmail)))
        //enter a valid email
        onView(withId(R.id.editTextText)).perform(replaceText("valid@email.com"))
        //expect no error message
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
    }
    @Test
    fun emptyPassword(){
        //checks if fields are there and enters a vaid email
        onView(withId(R.id.editTextText)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextTextPassword)).check(matches(isDisplayed()))
        onView(withId(R.id.button)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextText)).perform(replaceText("valid@email.address"))
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
        //expect message about empty password
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView5)).check(matches(withText(R.string.errorEmptyPassword)))
        //enter a valid password
        onView(withId(R.id.editTextTextPassword)).perform(replaceText("validPassword"))
        //expect no error message
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
    }
    @Test
    fun invalidEmail(){
        //checks fields and enters and invalid email with a valid password
        onView(withId(R.id.editTextText)).check(matches(isDisplayed()))
        onView(withId(R.id.button)).check(matches(isDisplayed()))
        onView(withId(R.id.editTextTextPassword)).check(matches(isDisplayed()))
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
        onView(withId(R.id.editTextText)).perform(replaceText("invalidEmailFormat"))
        onView(withId(R.id.editTextTextPassword)).perform(replaceText("testing"))
        //expect message about invalid email
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView5)).check(matches(withText(R.string.errorInvalidEmail)))
        //replace email with a valid one
        onView(withId(R.id.editTextText)).perform(replaceText("valid@email.com"))
        //expect no error message
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
    }
    //End to end functional test
    @Test
    fun inputtingAndDeletingData(){
        onView(withId(R.id.editTextText)).check(matches(isDisplayed()))//email field
        onView(withId(R.id.editTextTextPassword)).check(matches(isDisplayed()))//password field
        onView(withId(R.id.button)).check(matches(isDisplayed()))//login button
        onView(withId(R.id.button)).check(matches(isClickable()))
        //enters an invalid email with a valid password
        onView(withId(R.id.editTextText)).perform(replaceText("invalidEmailFormat"))
        onView(withId(R.id.editTextTextPassword)).perform(replaceText("testing"))
        //expects the password to be censored
        onView(withId(R.id.editTextTextPassword)).check(matches(withText("•".repeat(7))))
        //expect to see error message about invalid email
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView5)).check(matches(withText(R.string.errorInvalidEmail)))
        //replaces email with a valid one
        onView(withId(R.id.editTextText)).perform(replaceText("valid@email.com"))
        //empty password field
        onView(withId(R.id.editTextTextPassword)).perform(replaceText(""))
        //expect to see error message about empty password
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView5)).check(matches(withText(R.string.errorEmptyPassword)))
        //empty the email field
        onView(withId(R.id.editTextText)).perform(replaceText(""))
        //expect to see error message about empty fields
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView5)).check(matches(withText(R.string.errorEmptyFields)))
        //fills the password field and email remains empty
        onView(withId(R.id.editTextTextPassword)).perform(replaceText("testingPassword"))
        //expects the password to be censored
        onView(withId(R.id.editTextTextPassword)).check(matches(withText("•".repeat(15))))
        //expect to see error message about empty email
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView5)).check(matches(withText(R.string.errorEmptyEmail)))
        //replaces email with a valid one
        onView(withId(R.id.editTextText)).perform(replaceText("valid@email.com"))
        //navigating to create account page
        onView(withId(R.id.textView3)).check(matches(isDisplayed()))
        onView(withId(R.id.textView3)).check(matches(isClickable()))
        onView(withId(R.id.textView3)).perform(click())
        onView(withId(R.id.RegistrationPage)).check(matches(isDisplayed()))

        //all fields currently empty
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
        onView(withId(R.id.button2)).perform(click())
        //expect error message about empty fields to appear
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorEmptyFields)))
        //Populate fields with invalid email, valid username, and mismatched passwords
        onView(withId(R.id.editTextText3)).perform(replaceText("invalidEmail"))
        onView(withId(R.id.editTextText6)).perform(replaceText("exampleUser"))
        onView(withId(R.id.editTextText7)).perform(replaceText("password1"))
        onView(withId(R.id.editTextText8)).perform(replaceText("password2"))
        //expect message about invalid email
        onView(withId(R.id.button2)).perform(click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorInvalidEmail)))
        //remove username field
        onView(withId(R.id.editTextText6)).perform(replaceText(""))
        //expect message about empty fields
        onView(withId(R.id.button2)).perform(click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorEmptyFields)))
        //enter a valid email and username
        onView(withId(R.id.editTextText3)).perform(replaceText("valid@email.com"))
        onView(withId(R.id.editTextText6)).perform(replaceText("myUsername"))
        //expect error message about mismatched passwords
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.VISIBLE)))
        onView(withId(R.id.textView6)).check(matches(withText(R.string.errorMismatchedPasswords)))
        //enter matching passwords
        onView(withId(R.id.editTextText7)).perform(replaceText("matchingPassword"))
        onView(withId(R.id.editTextText8)).perform(replaceText("matchingPassword"))
        //expect error message to disappear
        onView(withId(R.id.button2)).perform(ViewActions.click())
        onView(withId(R.id.textView6)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
        //going back to sign in page
        Espresso.pressBack()
        //expect to see error message disappear
        onView(withId(R.id.button)).perform(click())
        onView(withId(R.id.textView5)).check(matches(withEffectiveVisibility(Visibility.INVISIBLE)))
    }

}